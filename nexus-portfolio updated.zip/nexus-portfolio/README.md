# 𝐍𝐄𝐗𝐔𝐒₿ | Bitcoin-Native Builder Portfolio

This portfolio showcases Bitcoin-native tools and includes a reusable Afro Pattern Component Library.

---

### 🚀 Deployment Instructions (GitHub Pages)

To deploy this portfolio live using GitHub Pages:

1. Push this code to your GitHub repository.
2. Go to **Settings > Pages**.
3. Under **Source**, select the `main` branch and set the root (`/`) folder.
4. Save changes — your site will be live shortly at:

    `https://<your-github-username>.github.io/nexus-portfolio/`

> Make sure all images, CSS, and SVG files are referenced correctly relative to the root.
