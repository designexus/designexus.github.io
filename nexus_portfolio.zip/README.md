
# 𝐍𝐄𝐗𝐔𝐒₿ — Bitcoin-Native Portfolio

**Live Site:** [designexus.github.io](https://designexus.github.io)

This is the personal portfolio of **NEXUS₿** — a visionary developer and designer blending Bitcoin, Lightning Network, culture, and machine learning into human-centered apps and APIs.

## Projects

- **BitRecharge** — Bitcoin wallet for Nigeria with voucher top-ups and Lightning integration.
- **greenroot₿** — A cannabis x Bitcoin initiative to support lifestyle, privacy, and circular economic models.
- **The Bitcoin Streetstore** — A merch/education fusion to orange pill the masses through wearable culture.

## Connect

- GitHub: [@designexus](https://github.com/designexus)
- Twitter/X: [@designexust](https://x.com/designexust)
- Instagram: [@lifespeakstome_info](https://instagram.com/lifespeakstome_info)
- YouTube: [@designexus](https://youtube.com/@designexus)
- Email: nexus@walletofsatoshi.com
